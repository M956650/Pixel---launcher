package com.example.pixellauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextClock
import android.widget.TextView

data class AppItem(
    val label: String,
    val pkg: String,
    val intent: Intent,
    val icon: Drawable
)

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var adapter: AppAdapter

    private val allApps = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildUi()
        setContentView(root)
        root.requestApplyInsets()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        buildDock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while we're already on top
        closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher never exits; Back just closes the drawer.
        closeDrawer()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)

        // ----- Home screen -----
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val date = TextClock(this).apply {
            format12Hour = "EEE, MMM d"
            format24Hour = "EEE, MMM d"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#66000000"))
        }
        val time = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(Color.parseColor("#E6FFFFFF"))
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#66000000"))
        }
        home.addView(date)
        home.addView(time)

        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f)) // spacer

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        home.addView(
            dock,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72))
        )

        val pill = TextView(this).apply {
            text = "  Search apps"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#5F6368"))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, dp(24), 0)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2FFFFFF"))
                cornerRadius = dp(28).toFloat()
            }
            setOnClickListener { openDrawer(true) }
        }
        home.addView(
            pill,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
                topMargin = dp(12)
                bottomMargin = dp(8)
            }
        )

        val gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float
            ): Boolean {
                if (e1 != null && e1.y - e2.y > dp(60) && vy < -600f) {
                    openDrawer(false)
                    return true
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                try {
                    startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                    )
                } catch (_: Exception) {
                }
            }
        })
        home.setOnTouchListener { _, ev -> gestures.onTouchEvent(ev); true }

        root.addView(
            home,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // ----- App drawer -----
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2121212"))
            visibility = View.GONE
            isClickable = true
        }

        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Color.parseColor("#99FFFFFF"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(20), 0, dp(20), 0)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFFFFF"))
                cornerRadius = dp(26).toFloat()
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = filterApps()
            })
            setOnEditorActionListener { _, _, _ ->
                shown.firstOrNull()?.let { launch(it) }
                true
            }
        }
        drawer.addView(
            search,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        )

        adapter = AppAdapter()
        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(16)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, dp(16), 0, 0)
            clipToPadding = false
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> launch(shown[pos]) }
            setOnItemLongClickListener { _, v, pos, _ -> showAppMenu(v, shown[pos]); true }
        }
        drawer.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(
            drawer,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, insets ->
            val top = insets.systemWindowInsetTop
            val bottom = insets.systemWindowInsetBottom
            home.setPadding(dp(24), top + dp(24), dp(24), bottom + dp(8))
            drawer.setPadding(dp(16), top + dp(12), dp(16), bottom + dp(8))
            insets
        }
    }

    private fun roundIcon(d: Drawable, sizeDp: Int): ImageView =
        ImageView(this).apply {
            setImageDrawable(d)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
            layoutParams = FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER)
        }

    // ---------------------------------------------------------------- Dock

    private fun buildDock() {
        dock.removeAllViews()
        val targets = listOf(
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:")),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        for (t in targets) {
            val ri = packageManager.queryIntentActivities(t, 0).firstOrNull() ?: continue
            val launchIntent = Intent(t)
                .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val cell = FrameLayout(this)
            cell.addView(roundIcon(ri.loadIcon(packageManager), 56))
            cell.setOnClickListener {
                try { startActivity(launchIntent) } catch (_: Exception) {}
            }
            dock.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
    }

    // ---------------------------------------------------------------- Apps

    private fun loadApps() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = packageManager.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { ri ->
                AppItem(
                    label = ri.loadLabel(packageManager).toString(),
                    pkg = ri.activityInfo.packageName,
                    intent = Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                    icon = ri.loadIcon(packageManager)
                )
            }
            .sortedBy { it.label.lowercase() }
        allApps.clear()
        allApps.addAll(list)
        filterApps()
    }

    private fun filterApps() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) })
        adapter.notifyDataSetChanged()
    }

    private fun launch(item: AppItem) {
        try {
            startActivity(item.intent)
            closeDrawer()
        } catch (_: Exception) {
        }
    }

    private fun showAppMenu(anchor: View, item: AppItem) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "App info")
            menu.add(0, 2, 1, "Uninstall")
            setOnMenuItemClickListener { m ->
                when (m.itemId) {
                    1 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:${item.pkg}"))
                    )
                    2 -> startActivity(
                        Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${item.pkg}"))
                    )
                }
                true
            }
            show()
        }
    }

    // ---------------------------------------------------------------- Drawer

    private fun openDrawer(focusSearch: Boolean) {
        if (drawer.visibility == View.VISIBLE) return
        search.setText("")
        loadApps()
        drawer.animate().cancel()
        drawer.translationY = root.height.toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().translationY(0f).setDuration(220).start()
        if (focusSearch) {
            search.requestFocus()
            search.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(search, 0)
            }, 250)
        }
    }

    private fun closeDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
        drawer.animate().cancel()
        drawer.animate()
            .translationY(root.height.toFloat())
            .setDuration(200)
            .withEndAction { drawer.visibility = View.GONE }
            .start()
    }

    // ---------------------------------------------------------------- Adapter

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val item = shown[position]
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(4), dp(4), dp(4))
                val iconWrap = FrameLayout(context)
                iconWrap.addView(roundIcon(item.icon, 52))
                addView(iconWrap, LinearLayout.LayoutParams(dp(56), dp(56)))
                addView(TextView(context).apply {
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(6) })
            }
            val iconView = ((cell.getChildAt(0) as FrameLayout).getChildAt(0)) as ImageView
            iconView.setImageDrawable(item.icon)
            (cell.getChildAt(1) as TextView).text = item.label
            return cell
        }
    }
}
